#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* replace_string(char*, char*, char*);
void correct_end_of_string(char*);